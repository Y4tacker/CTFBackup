package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class UserController {

    @RequestMapping("/userinfo")
    public String userinfo(String username) throws Exception {
        return username;

    }

    @RequestMapping("/leak")
    public String leakInterface(String leak) throws Exception {
        return leak;

    }

    @RequestMapping("/user/{name}")
    @ResponseBody
    public String getinfo(@PathVariable String name){
        return "Hello, I'm "+name;
    }

}
