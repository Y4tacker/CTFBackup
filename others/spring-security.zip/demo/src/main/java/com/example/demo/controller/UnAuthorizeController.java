package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UnAuthorizeController {


    @RequestMapping("/unauthorize")
    @ResponseBody
    public String UnAuthorize(){
        return "bypass!";
    }

}
