DROP TABLE IF EXISTS flag;
create table flag (flag varchar(50));
insert into flag(flag) value("flag{xxx}");