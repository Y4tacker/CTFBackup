# phpjiami网站解密脚本

## 使用说明

原作者连链接
'''
http://sec2hack.com/web/phpjiami-decode.html
'''
> 注：原作者博客已保存

+ 1.将要加密文件放入encode文件夹中
+ 2.运行phpjiami.php
+ 3.decode文件夹中就是解密文件
