<?php
@session_start();
date_default_timezone_set("PRC");
header('Content-Type:text/html;charset=utf-8');
define('ROOT_PATH',str_replace('\\','/',dirname(dirname(__FILE__))));
define('HOST', $_SERVER['HTTP_HOST']);
define('DEBUG', false);
include_once(''.ROOT_PATH.'/include/rockFun.php');
include_once(''.ROOT_PATH.'/include/Chajian.php');
include_once(''.ROOT_PATH.'/include/class/rockClass.php');
$rock 		= new rockClass();
$db			= null;		
$smarty		= false;
define('REWRITE', 'true');
if(!defined('PROJECT'))define('PROJECT', 'web');

$config		= array(
	'title'		=> 'ROCKOA',
	'url'		=> 'http://'.HOST.'/',
	'urly'		=> 'http://www.xh829.com/',
	'db_host'	=> 'localhost',
	'db_user'	=> 'root',
	'db_pass'	=> '666666',
	'db_base'	=> 'rainrock',
	'perfix'	=> 'rock_',
	'qom'		=> 'rock_',
	'highpass'	=> 'rock123456',
	'install'	=> false
);


$_confpath		= $rock->strformat('?0/?1/?1Config.php', ROOT_PATH, PROJECT);
if(file_exists($_confpath)){
	$_tempconf	= require($_confpath);
	foreach($_tempconf as $_tkey=>$_tvs)$config[$_tkey] = $_tvs;
}


define('TITLE', $config['title']);
define('URL', $config['url']);
define('URLY', $config['urly']);

define('DB_HOST', $config['db_host']);
define('DB_USER', $config['db_user']);
define('DB_PASS', $config['db_pass']);
define('DB_BASE', $config['db_base']);

define('PREFIX', $config['perfix']);
define('QOM', $config['qom']);
define('HIGHPASS', $config['highpass']);

$rock->jm = c('jm', true);